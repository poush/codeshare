<?php 
            return array(
				'version' => '1.4',
				'info' => '',
				'lastCheck' => 'Monday 4th of August 2014 06:58:33 AM[UTC]',
				'outdated' =>  false
				) 
			?>